package com.paradox.app

import android.app.Activity
import android.os.Bundle
import android.widget.*
import org.json.JSONObject

class CustomActivity : Activity() {
    private lateinit var box: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        val types = listOf("app" to "Открыть приложение", "url" to "Открыть ссылку", "call" to "Набрать номер", "say" to "Сказать фразу")
        val phrase = EditText(this).apply { hint = "Фраза, например: включи мою музыку" }
        val spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@CustomActivity, android.R.layout.simple_spinner_dropdown_item, types.map { it.second })
        }
        val value = EditText(this).apply { hint = "Приложение / ссылка / номер / текст ответа" }
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val add = Button(this).apply {
            text = "Добавить"
            setOnClickListener {
                if (phrase.text.isNotBlank() && value.text.isNotBlank()) {
                    val a = Custom.load(this@CustomActivity)
                    a.put(JSONObject().put("phrase", phrase.text.toString().trim())
                        .put("type", types[spin.selectedItemPosition].first).put("value", value.text.toString().trim()))
                    Custom.save(this@CustomActivity, a)
                    phrase.setText(""); value.setText(""); refresh()
                }
            }
        }
        listOf(TextView(this).apply { text = "Свои команды"; textSize = 22f }, phrase, spin, value, add, box).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun refresh() {
        box.removeAllViews()
        val a = Custom.load(this)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            box.addView(Button(this).apply {
                text = "✕  «${o.getString("phrase")}» → ${o.getString("value")}"; isAllCaps = false
                setOnClickListener { a.remove(i); Custom.save(this@CustomActivity, a); refresh() }
            })
        }
    }
}
