package com.paradox.app

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings

// Быстрые команды «открой …»: открывают нужный экран или приложение без интернета и без ИИ.
object Quick {
    private fun cat(c: String) = Intent(Intent.ACTION_MAIN).addCategory(c)
    private val TABLE: List<Pair<List<String>, Intent>> = listOf(
        listOf("вайфай", "вай фай", "wi fi", "wifi") to Intent(Settings.ACTION_WIFI_SETTINGS),
        listOf("блютуз", "блютус", "bluetooth") to Intent(Settings.ACTION_BLUETOOTH_SETTINGS),
        listOf("режим полёта", "режим полета", "авиарежим") to Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS),
        listOf("мобильные данные", "мобильный интернет") to Intent(Settings.ACTION_DATA_ROAMING_SETTINGS),
        listOf("геолокацию", "местоположение", "геолокация") to Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS),
        listOf("настройки экрана", "настройки дисплея") to Intent(Settings.ACTION_DISPLAY_SETTINGS),
        listOf("настройки звука") to Intent(Settings.ACTION_SOUND_SETTINGS),
        listOf("экономию заряда", "энергосбережение", "экономию батареи") to Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
        listOf("хранилище", "память телефона") to Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
        listOf("nfc", "нфс") to Intent(Settings.ACTION_NFC_SETTINGS),
        listOf("дату и время", "настройки времени") to Intent(Settings.ACTION_DATE_SETTINGS),
        listOf("настройки языка", "язык") to Intent(Settings.ACTION_LOCALE_SETTINGS),
        listOf("о телефоне") to Intent(Settings.ACTION_DEVICE_INFO_SETTINGS),
        listOf("специальные возможности") to Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
        listOf("точку доступа", "раздачу интернета", "режим модема") to Intent(Settings.ACTION_WIRELESS_SETTINGS),
        listOf("впн", "vpn") to Intent(Settings.ACTION_VPN_SETTINGS),
        listOf("безопасность") to Intent(Settings.ACTION_SECURITY_SETTINGS),
        listOf("список приложений") to Intent(Settings.ACTION_APPLICATION_SETTINGS),
        listOf("видеокамеру", "запись видео") to Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA),
        listOf("камеру", "камера") to Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
        listOf("галерею", "галерея") to cat(Intent.CATEGORY_APP_GALLERY),
        listOf("контакты") to Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI),
        listOf("сообщения", "смс") to cat(Intent.CATEGORY_APP_MESSAGING),
        listOf("браузер") to cat(Intent.CATEGORY_APP_BROWSER),
        listOf("календарь") to cat(Intent.CATEGORY_APP_CALENDAR),
        listOf("калькулятор") to cat(Intent.CATEGORY_APP_CALCULATOR),
        listOf("почту") to cat(Intent.CATEGORY_APP_EMAIL),
        listOf("карты") to cat(Intent.CATEGORY_APP_MAPS),
        listOf("будильники", "часы") to Intent(AlarmClock.ACTION_SHOW_ALARMS),
        listOf("набор номера", "телефон") to Intent(Intent.ACTION_DIAL),
        listOf("настройки") to Intent(Settings.ACTION_SETTINGS)
    )

    fun run(ctx: Context, t: String): String? {
        if (Regex("ярче|увеличь яркость|прибавь яркость").containsMatchIn(t)) return bright(ctx, 60)
        if (Regex("темнее|убавь яркость|уменьши яркость").containsMatchIn(t)) return bright(ctx, -60)
        if (t.startsWith("найди") && listOf("в интернете", "в браузере").any { t.contains(it) }) {
            val q = t.removePrefix("найди").replace("в интернете", "").replace("в браузере", "").trim()
            return go(ctx, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q), "Ищу: $q")
        }
        if (!listOf("открой", "включи", "покажи", "зайди").any { t.startsWith(it) }) return null
        for ((keys, intent) in TABLE) {
            val k = keys.firstOrNull { t.contains(it) } ?: continue
            return go(ctx, Intent(intent), "Открываю $k")
        }
        return null
    }

    private fun go(ctx: Context, i: Intent, ok: String) = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); ok
    } catch (e: Exception) { "!Не получилось открыть" }

    private fun bright(ctx: Context, d: Int): String {
        if (!Settings.System.canWrite(ctx)) {
            go(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)), "")
            return "!Дайте Zepik право менять настройки, потом повторите"
        }
        val r = ctx.contentResolver
        Settings.System.putInt(r, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        val cur = Settings.System.getInt(r, Settings.System.SCREEN_BRIGHTNESS, 128)
        Settings.System.putInt(r, Settings.System.SCREEN_BRIGHTNESS, (cur + d).coerceIn(10, 255))
        return if (d > 0) "Ярче" else "Темнее"
    }
}
