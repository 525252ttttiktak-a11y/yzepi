package com.paradox.app

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.speech.tts.TextToSpeech
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("p", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 15f; setPadding(0, pad, 0, 0) }
        val key = EditText(this).apply {
            hint = "API-ключ Gemini"; setText(p.getString("k", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val model = EditText(this).apply { setText(p.getString("model", "gemini-flash-latest")) }
        val persona = EditText(this).apply {
            hint = "Например: Ты весёлый помощник по имени Зепик"; setText(p.getString("persona", ""))
        }
        val voice = Switch(this).apply { text = "Отвечать голосом"; isChecked = p.getBoolean("voice", true) }
        val wake = EditText(this).apply { setText(p.getString("wake", "зепик")) }
        val pitch = SeekBar(this).apply { max = 100; progress = p.getInt("pitch", 85) - 50 }
        val rate = SeekBar(this).apply { max = 150; progress = p.getInt("rate", 100) - 50 }
        val btnVoice = Button(this).apply {
            text = "Выбрать голос озвучки (системные настройки)"
            setOnClickListener {
                try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
                catch (e: Exception) { Toast.makeText(this@SettingsActivity, "Открой Настройки → Язык и ввод → Синтез речи", Toast.LENGTH_LONG).show() }
            }
        }
        val btnSvc = Button(this).apply {
            text = "Включить службу Zepik"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        Speaker.init(this)
        val btnPick = Button(this).apply { text = "Выбрать голос"; setOnClickListener { pickVoice(p) } }
        val btnDl = Button(this).apply {
            text = "Скачать голоса"
            setOnClickListener {
                try { startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) }
                catch (e: Exception) { try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (e2: Exception) {} }
            }
        }
        val offline = Switch(this).apply { text = "Распознавать речь офлайн (если скачан пакет)"; isChecked = p.getBoolean("offline", false) }
        val city = EditText(this).apply { hint = "Например: Москва"; setText(p.getString("city", "")) }
        val repo = EditText(this).apply { hint = "пользователь/yzepi"; setText(p.getString("repo", "")) }
        val btnCustom = Button(this).apply {
            text = "Свои команды"
            setOnClickListener { startActivity(Intent(this@SettingsActivity, CustomActivity::class.java)) }
        }
        val btnUpd = Button(this).apply {
            text = "Проверить обновления"
            setOnClickListener {
                val r = repo.text.toString().trim()
                p.edit().putString("repo", r).apply()
                Updater.check(this@SettingsActivity, r) { m -> runOnUiThread { Toast.makeText(this@SettingsActivity, m, Toast.LENGTH_LONG).show() } }
            }
        }
        val orb = Switch(this).apply { text = "Анимация аватара"; isChecked = p.getBoolean("orb", true) }
        val dark = Switch(this).apply { text = "Тёмная тема"; isChecked = p.getBoolean("dark", true) }
        val save = Button(this).apply {
            text = "Сохранить"
            setOnClickListener {
                p.edit().putString("k", key.text.toString().trim()).putString("model", model.text.toString().trim())
                    .putString("persona", persona.text.toString()).putBoolean("voice", voice.isChecked)
                    .putInt("rate", rate.progress + 50).putInt("pitch", pitch.progress + 50).putBoolean("offline", offline.isChecked).putString("city", city.text.toString().trim()).putString("repo", repo.text.toString().trim()).putBoolean("orb", orb.isChecked).putBoolean("dark", dark.isChecked).putString("wake", wake.text.toString().trim().lowercase()).apply()
                finish()
            }
        }
        listOf(label("API-ключ"), key, label("Модель Gemini"), model, label("Характер и имя ассистента"), persona,
            voice, label("Кодовое слово (скажи его, чтобы разбудить)"), wake, label("Скорость речи"), rate, label("Высота голоса (ниже = басовитее)"), pitch, label("Город для погоды"), city, orb, dark, offline, btnPick, btnDl, btnVoice, btnSvc, btnCustom, label("Репозиторий GitHub для обновлений"), repo, btnUpd, save).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun pickVoice(p: SharedPreferences) {
        val vs = Speaker.voices()
        if (vs.isEmpty()) { Toast.makeText(this, "Русских голосов нет. Нажми «Скачать голоса»", Toast.LENGTH_LONG).show(); return }
        val names = vs.map { it.name + if (it.isNetworkConnectionRequired) " (онлайн)" else " (офлайн)" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Голос").setItems(names) { _, i ->
            p.edit().putString("voiceName", vs[i].name).apply()
            Speaker.speak(this, "Так я буду звучать")
        }.show()
    }
}
