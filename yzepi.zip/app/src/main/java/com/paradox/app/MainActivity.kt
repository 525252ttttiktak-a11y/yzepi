package com.paradox.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var btnJ: Button
    private lateinit var btnCam: Button
    private lateinit var btnGal: Button
    private lateinit var orb: Orb
    private lateinit var status: TextView
    private lateinit var mainView: View
    private lateinit var panelView: View
    private lateinit var swProf: Switch
    private lateinit var swGame: Switch
    private var camUri: Uri? = null
    private var autoTried = false
    private var updating = false
    private var dark = true
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val fg get() = if (dark) Color.WHITE else Color.BLACK
    private fun shape(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
        background = shape(if (dark) 0xFF161B28.toInt() else 0xFFF2F4F8.toInt(), 16)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Speaker.init(this)
        dark = prefs.getBoolean("dark", true)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(36), dp(12), dp(8))
            setBackgroundColor(if (dark) Color.parseColor("#0E1118") else Color.WHITE)
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text = "Zepik"; textSize = 26f; setTextColor(fg) }, LinearLayout.LayoutParams(0, -2, 1f))
        btnJ = Button(this).apply { setOnClickListener { toggleVoice() } }
        head.addView(btnJ)
        head.addView(Button(this).apply {
            text = "⚙"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        val tabs = LinearLayout(this)
        tabs.addView(Button(this).apply { text = "Основное окно"; setOnClickListener { tab(true) } }, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(Button(this).apply { text = "Панель управления"; setOnClickListener { tab(false) } }, LinearLayout.LayoutParams(0, -2, 1f))

        // Основное окно: аватар, история команд, ввод
        orb = Orb(this)
        status = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setTextColor(fg) }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(list) }
        val history = card()
        history.addView(TextView(this).apply { text = "История команд"; textSize = 16f; setTextColor(fg) })
        history.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        input = EditText(this).apply { hint = "Команда или вопрос"; setTextColor(fg); setHintTextColor(Color.GRAY) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        btnCam = Button(this).apply { text = "📷"; setOnClickListener { takePhoto() } }
        btnGal = Button(this).apply {
            text = "🖼"
            setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 4) }
        }
        bar.addView(btnCam); bar.addView(btnGal)
        bar.addView(Button(this).apply {
            text = "➤"
            setOnClickListener {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) { input.setText(""); Brain.handle(this@MainActivity, t) }
            }
        })
        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        main.addView(orb, LinearLayout.LayoutParams(dp(90), dp(90)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        main.addView(status, LinearLayout.LayoutParams(-1, -2))
        main.addView(history, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(bar)
        mainView = main

        // Панель управления
        val panel = card()
        fun sw(title: String, on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
            text = title; setTextColor(fg); isChecked = on; setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, c -> if (!updating) f(c) }
        }.also { panel.addView(it) }
        swProf = sw("Режим профессора (учёба, фото)", false) { Brain.setMode(this, if (it) "study" else "jarvis") }
        swGame = sw("Игровой режим (не беспокоить)", false) { Brain.setMode(this, if (it) "game" else "jarvis") }
        sw("Тёмная тема", dark) { prefs.edit().putBoolean("dark", it).apply(); recreate() }
        sw("Анимация аватара", prefs.getBoolean("orb", true)) { prefs.edit().putBoolean("orb", it).apply(); orb.setActive(it && VoiceService.running) }
        sw("Окно поверх приложений", prefs.getBoolean("overlayOn", true)) {
            prefs.edit().putBoolean("overlayOn", it).apply()
            val s = ParadoxService.instance
            if (s != null) { if (it) Overlay.show(s) else Overlay.hide(s) } else if (it) add("Включите службу Zepik в настройках телефона", false)
        }
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val volLabel = TextView(this).apply { setTextColor(fg); setPadding(0, dp(10), 0, 0) }
        panel.addView(volLabel)
        panel.addView(SeekBar(this).apply {
            max = 100; progress = am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / mx
            volLabel.text = "Громкость: $progress%"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    volLabel.text = "Громкость: $v%"
                    if (u) am.setStreamVolume(AudioManager.STREAM_MUSIC, mx * v / 100, 0)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        panelView = ScrollView(this).apply { addView(panel); visibility = View.GONE }

        val content = FrameLayout(this)
        content.addView(mainView, FrameLayout.LayoutParams(-1, -1))
        content.addView(panelView, FrameLayout.LayoutParams(-1, -1))
        root.addView(head); root.addView(tabs)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        add("Zepik к вашим услугам.", false)
    }

    private fun tab(main: Boolean) {
        val show = if (main) mainView else panelView
        val hide = if (main) panelView else mainView
        hide.visibility = View.GONE
        show.alpha = 0f; show.visibility = View.VISIBLE
        show.animate().alpha(1f).setDuration(250).start()
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean("dark", true) != dark) { recreate(); return }
        Brain.ui = { t, m -> add(t, m) }
        Brain.onMode = { runOnUiThread { applyModeUi() } }
        applyModeUi()
        if (!autoTried) {
            autoTried = true
            if (!VoiceService.running && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
        }
    }

    override fun onPause() { Brain.ui = null; Brain.onMode = null; super.onPause() }

    private fun applyModeUi() {
        val m = prefs.getString("mode", "jarvis")!!
        updating = true; swProf.isChecked = m == "study"; swGame.isChecked = m == "game"; updating = false
        val v = if (m == "study") View.VISIBLE else View.GONE
        btnCam.visibility = v; btnGal.visibility = v
        val on = VoiceService.running
        btnJ.text = if (on) "🎙 Вкл" else "🎙 Выкл"
        status.text = if (on) "Слушаю. Скажи «Зепик, …»" else "Отдыхаю"
        orb.setActive(on && prefs.getBoolean("orb", true))
    }

    private fun toggleVoice() {
        if (VoiceService.running) {
            stopService(Intent(this, VoiceService::class.java)); btnJ.text = "🎙 Выкл"
            status.text = "Отдыхаю"; orb.setActive(false)
        } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoice()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 2)
        }
    }

    private fun startVoice() {
        startForegroundService(Intent(this, VoiceService::class.java)); btnJ.text = "🎙 Вкл"
        status.text = "Слушаю. Скажи «Зепик, …»"; orb.setActive(prefs.getBoolean("orb", true))
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
        else add("Без доступа к микрофону голос не работает", false)
    }

    private fun takePhoto() {
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "zepik_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        }
        camUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, camUri), 3)
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (res != RESULT_OK) return
        val uri = if (rc == 3) camUri else if (rc == 4) data?.data else null
        if (uri != null) sendImage(uri)
    }

    private fun sendImage(uri: Uri) {
        val q = input.text.toString().trim().ifEmpty { "Что на фото? Если это задание, реши его и объясни." }
        input.setText("")
        Thread {
            try {
                val bmp = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
                val k = 1024f / maxOf(bmp.width, bmp.height)
                val sc = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
                val out = ByteArrayOutputStream()
                sc.compress(Bitmap.CompressFormat.JPEG, 80, out)
                Brain.handle(this, q, Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
            } catch (e: Exception) {
                add("Не удалось открыть фото: ${e.message}", false)
            }
        }.start()
    }

    private fun add(text: String, mine: Boolean) = runOnUiThread {
        val v = TextView(this).apply {
            this.text = text; textSize = 16f; setTextColor(fg)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = shape(Color.parseColor(if (dark) (if (mine) "#22406E" else "#1F2638") else (if (mine) "#CFE8FF" else "#E4E7EE")), 12)
            alpha = 0f
        }
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.setMargins(if (mine) dp(48) else 0, dp(4), if (mine) 0 else dp(48), dp(4))
        lp.gravity = if (mine) Gravity.END else Gravity.START
        list.addView(v, lp)
        v.animate().alpha(1f).setDuration(250).start()
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
