package com.paradox.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.net.URL

// Проверяет последний релиз на GitHub (репозиторий вида «пользователь/yzepi»).
object Updater {
    fun check(ctx: Context, repo: String, say: (String) -> Unit) {
        if (!repo.contains("/")) { say("Укажите репозиторий в настройках, например пользователь/yzepi"); return }
        Thread {
            try {
                val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection()
                c.connectTimeout = 15000; c.readTimeout = 15000
                val j = JSONObject(c.getInputStream().bufferedReader().readText())
                val latest = j.getString("tag_name").removePrefix("v").toIntOrNull() ?: 0
                @Suppress("DEPRECATION")
                val cur = ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode
                if (latest > cur) {
                    val url = j.getJSONArray("assets").getJSONObject(0).getString("browser_download_url")
                    say("Есть обновление v$latest. Открываю загрузку.")
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else say("У вас последняя версия (v$cur).")
            } catch (e: Exception) { say("Не получилось проверить обновления") }
        }.start()
    }
}
