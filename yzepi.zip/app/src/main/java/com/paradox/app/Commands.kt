package com.paradox.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.view.KeyEvent
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Быстрые команды по фразам: работают без интернета и без ИИ. Возвращают текст или null (не моя команда).
// Если текст начинается с "!", его нужно озвучить.
object Commands {
    fun run(ctx: Context, raw: String): String? {
        val t = raw.lowercase().replace(Regex("[^а-яёa-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
            .replace(Regex("^запусти(ть)? (приложение )?"), "открой ").replace("открой приложение ", "открой ")
        Custom.match(ctx, t)?.let { return it }
        Quick.run(ctx, t)?.let { return it }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val svc = ParadoxService.instance
        fun has(vararg w: String) = w.any { t.contains(it) }
        fun vol(dir: Int) { repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI) } }
        fun key(k: Int) {
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k))
        }
        fun glob(a: Int, ok: String) = if (svc == null) "!Включите службу Zepik в настройках" else { svc.performGlobalAction(a); ok }
        val off = has("выключи", "отключи", "выйди")
        return when {
            t.startsWith("поставь громкость") || t.startsWith("громкость на") || t.startsWith("установи громкость") -> {
                val n = Regex("(\\d{1,3})").find(t)?.value?.toInt()
                if (n == null) "!На сколько процентов?" else {
                    val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, mx * n.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI)
                    "Громкость $n%"
                }
            }
            has("будильник") && has("поставь", "заведи", "установи") -> alarm(ctx, t)
            has("напомни") -> remind(ctx, t)
            has("погода", "погоду") -> { weather(ctx); "~" }
            has("обновлен") && has("проверь", "найди") -> {
                Updater.check(ctx, ctx.getSharedPreferences("p", Context.MODE_PRIVATE).getString("repo", "")!!) { Brain.reply(ctx, it) }
                "~"
            }
            has("позвони") && t.replace(" ", "").contains(Regex("\\d{5,}")) -> {
                ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + t.replace(Regex("[^0-9]"), ""))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Набираю номер"
            }
            has("тише", "убавь звук", "уменьши звук", "потише") -> { vol(AudioManager.ADJUST_LOWER); "Тише" }
            has("громче", "прибавь звук", "увеличь звук", "погромче") -> { vol(AudioManager.ADJUST_RAISE); "Громче" }
            has("выключи звук", "без звука") -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "Звук выключен" }
            has("сверни все окна", "сверни окна", "на главный экран", "рабочий стол") || t == "домой" -> glob(AccessibilityService.GLOBAL_ACTION_HOME, "Главный экран")
            t == "назад" -> glob(AccessibilityService.GLOBAL_ACTION_BACK, "Назад")
            has("скриншот", "снимок экрана") -> glob(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Скриншот")
            has("недавние", "переключи приложение") -> glob(AccessibilityService.GLOBAL_ACTION_RECENTS, "Недавние")
            has("заблокируй экран", "заблокируй телефон") -> glob(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Экран заблокирован")
            has("шторку", "открой уведомления") -> glob(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Уведомления")
            has("концентрации", "не беспокоить") -> { Brain.dnd(ctx, !off); if (off) "Концентрация выключена" else "Концентрация включена" }
            has("фонарик") -> try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], !off); if (off) "Фонарик выключен" else "Фонарик включён"
            } catch (e: Exception) { "!Не получилось включить фонарик" }
            has("пауза", "останови музыку") -> { key(KeyEvent.KEYCODE_MEDIA_PAUSE); "Пауза" }
            has("включи музыку", "продолжи музыку") -> { key(KeyEvent.KEYCODE_MEDIA_PLAY); "Музыка" }
            has("следующий трек", "следующая песня", "следующий") || t == "дальше" -> { key(KeyEvent.KEYCODE_MEDIA_NEXT); "Следующий трек" }
            has("предыдущий трек", "прошлый трек", "предыдущий") -> { key(KeyEvent.KEYCODE_MEDIA_PREVIOUS); "Предыдущий трек" }
            has("сколько времени", "который час") -> "!Сейчас " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            t.startsWith("открой ") && !t.contains(" и ") -> {
                val n = t.removePrefix("открой ").trim()
                val pm = ctx.packageManager
                val app = pm.getInstalledApplications(0).firstOrNull { pm.getApplicationLabel(it).toString().contains(n, ignoreCase = true) }
                val li = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
                if (li != null) { ctx.startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Открываю $n" } else null
            }
            else -> null
        }
    }

    private fun alarm(ctx: Context, t: String): String {
        val m = Regex("(\\d{1,2})(?:[: ](\\d{2}))?").find(t.substringAfter("на ", t)) ?: return "!На какое время поставить будильник?"
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if ((t.contains("вечера") || t.contains("дня")) && h < 12) h += 12
        if (h > 23 || min > 59) return "!Не понял время"
        ctx.startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Будильник на %02d:%02d".format(h, min)
    }

    private fun remind(ctx: Context, t: String): String {
        val m = Regex("через (\\d+) (секунд|минут|час)").find(t) ?: return "!Через сколько напомнить?"
        val n = m.groupValues[1].toInt()
        val sec = n * when (m.groupValues[2]) { "секунд" -> 1; "минут" -> 60; else -> 3600 }
        val msg = t.replace(m.value, "").replace("напомни мне", "").replace("напомни", "").trim().ifEmpty { "Напоминание" }
        ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_MESSAGE, msg)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Напомню: $msg"
    }

    private fun get(u: String) = (URL(u).openConnection() as HttpURLConnection)
        .apply { connectTimeout = 15000; readTimeout = 15000 }.inputStream.bufferedReader().readText()

    private fun weather(ctx: Context) {
        val city = ctx.getSharedPreferences("p", Context.MODE_PRIVATE).getString("city", "")!!
        if (city.isBlank()) { Brain.reply(ctx, "Укажите город для погоды в настройках"); return }
        Thread {
            try {
                val r = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&name=" + URLEncoder.encode(city, "UTF-8")))
                    .getJSONArray("results").getJSONObject(0)
                val w = JSONObject(get("https://api.open-meteo.com/v1/forecast?current=temperature_2m,weather_code,wind_speed_10m&wind_speed_unit=ms" +
                    "&latitude=${r.getDouble("latitude")}&longitude=${r.getDouble("longitude")}")).getJSONObject("current")
                val d = when (w.getInt("weather_code")) {
                    0 -> "ясно"; 1, 2, 3 -> "облачно"; 45, 48 -> "туман"; in 51..67 -> "дождь"
                    in 71..77 -> "снег"; in 80..82 -> "ливень"; in 95..99 -> "гроза"; else -> "переменно"
                }
                Brain.reply(ctx, "В городе ${r.getString("name")} сейчас ${Math.round(w.getDouble("temperature_2m"))} градусов, $d, " +
                    "ветер ${Math.round(w.getDouble("wind_speed_10m"))} метров в секунду")
            } catch (e: Exception) { Brain.reply(ctx, "Не получилось узнать погоду") }
        }.start()
    }
}
