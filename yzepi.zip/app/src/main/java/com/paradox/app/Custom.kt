package com.paradox.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONArray

// Свои команды: фраза -> действие. Хранятся в настройках телефона.
object Custom {
    fun load(ctx: Context) = JSONArray(ctx.getSharedPreferences("p", Context.MODE_PRIVATE).getString("custom", "[]"))
    fun save(ctx: Context, a: JSONArray) { ctx.getSharedPreferences("p", Context.MODE_PRIVATE).edit().putString("custom", a.toString()).apply() }

    fun match(ctx: Context, t: String): String? {
        val a = load(ctx)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val ph = o.getString("phrase").lowercase().trim()
            if (ph.isNotEmpty() && t.contains(ph)) return run(ctx, o.getString("type"), o.getString("value"))
        }
        return null
    }

    private fun run(ctx: Context, type: String, v: String): String = try {
        when (type) {
            "app" -> {
                val pm = ctx.packageManager
                val app = pm.getInstalledApplications(0).firstOrNull { pm.getApplicationLabel(it).toString().contains(v, ignoreCase = true) }
                val li = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
                if (li != null) { ctx.startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Открываю $v" } else "!Не нашёл приложение $v"
            }
            "url" -> {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(if (v.startsWith("http")) v else "https://$v")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Открываю ссылку"
            }
            "call" -> {
                ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$v")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Набираю номер"
            }
            else -> "!$v"
        }
    } catch (e: Exception) { "!Не получилось выполнить команду" }
}
